<?php
$a = 50 ;
$b = 5;
$c = 3;


echo $a % $b . "<br>";

echo $a % $c . "<br>";
