<?php

if(5==10){
    echo "a 1° está correta";
}
else{
    echo " a 1° está incorreta";
}