<?php


$saudacao = "Saudacoes, seja bem vindo a: ";

$nomeEmpresa = "TechLab";

$nomeUsuario = "Dermival";



echo $saudacao . $nomeEmpresa . " como podemos ajuda-lo sr." . $nomeUsuario . "?";

