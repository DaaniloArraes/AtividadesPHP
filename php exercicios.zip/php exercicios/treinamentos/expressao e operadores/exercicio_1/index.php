<?php

$a = 1;
$b = 110;
$c = 13;


$subtacao = $b - $c;


$multiplicacao = $b * $c;


echo $multiplicacao;

echo "<br>";


echo $subtacao;
