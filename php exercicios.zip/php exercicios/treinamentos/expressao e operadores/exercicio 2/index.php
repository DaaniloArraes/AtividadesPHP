<?php

$variavel = "5" * 12;


echo gettype($variavel);