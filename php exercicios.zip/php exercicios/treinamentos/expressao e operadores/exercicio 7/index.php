<?php


if( 15 > 5 && "João" === "João"){
    echo "primeiro teste";
}

if(3 > 5 || 1){
    echo "Segundo Teste";
}

if(2 === 3 && 5 >= 3){
    echo "terceiro teste";

}
