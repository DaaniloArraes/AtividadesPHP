<?php

$a = 5;
$b = 3;


echo $a == $b ? "verdadeiro" : "false";
echo "<br>";
echo $a != $b;
echo "<br>";
echo $a === $b;
echo "<br>";
echo $a !== $b;