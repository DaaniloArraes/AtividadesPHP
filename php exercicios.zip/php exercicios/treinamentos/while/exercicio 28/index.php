<?php
    $x =0;
    
    while($x <= 30){
        echo $x . "<br>";         
        
        if($x === 24) 
            break;
        
        $x++;
    }

?>