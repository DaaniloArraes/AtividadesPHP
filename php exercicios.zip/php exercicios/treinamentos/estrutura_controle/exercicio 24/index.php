<?php

$variavelString = "testando";
$variavelInt = 79;
$variavelBoolean = true;

if($variavelInt > 80){
    echo "Variavel muito pesada";
}
else{ echo  "está leve"; }
?>