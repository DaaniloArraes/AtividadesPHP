<?php

$idade1 = 8;
$idade2 = 17;

if($idade1 >= 18 && $idade2 >= 18 ){
    echo "as idades são maiores que 18";
}
else{
    echo "as idades não são maiores de 18";
}

?>