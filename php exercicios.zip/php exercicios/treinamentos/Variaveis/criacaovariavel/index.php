<?php
$notaM1 = 250;
$notaM2 = 330;

echo $notaM1 + $notaM2;
?>