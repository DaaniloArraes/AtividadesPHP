<?php

 $x = "nome";

 echo $x;
 echo "<br>";
 $$x = "Danilo" ; 

 echo $$x;
 echo "<br>";
 echo $x;

