<?php

    $a = 1.12;

    $b = 10;

    echo $a;
    echo "<br>";

    if(is_float($b)){
        
       
        echo  " é um numero decimal";

    }

    else{
        echo  " não é um numero decimal";
    }

    ?>