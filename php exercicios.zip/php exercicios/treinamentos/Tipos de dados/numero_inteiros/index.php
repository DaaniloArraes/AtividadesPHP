<?php
    
    echo 1 ;
    echo  "<br>";
    echo 2 ;
    echo  "<br>";
    echo 3 ;

    echo  "<br>";

    $numeroTeste    = 10074;

    if(is_int($numeroTeste)){

        echo "é um inteiro";

    } 
    

?>