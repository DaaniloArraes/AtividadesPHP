<h1>Testando o Include</h1>

<?php
    $c = 30
?>