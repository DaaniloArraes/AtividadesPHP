<?php
include("teste.php");
?>


<p> Após o Include <?php echo $c ?> </p>