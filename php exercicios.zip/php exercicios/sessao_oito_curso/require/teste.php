<Div>
    <h1> Encontre os melhores produtos:</h1>
    <p> Canetão BIC R$1.00</p>
</Div>