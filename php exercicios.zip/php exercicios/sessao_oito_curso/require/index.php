<p>Testando</p>
<?php 
    require("teste.php");
?>

<p>Arquivo do Include</p>