<?php 
    $array = ["Feijão", "Arroz", "Bife de Frango", "Ovo de galinha"];


    echo implode(", ", $array);


?>