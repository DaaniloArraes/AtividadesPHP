<?php
    function imprimirDados($nome, $idade) {  
        echo "Olá $nome, vc tem $idade anos!";
    }

    imprimirDados("Danilo", 29);

?>