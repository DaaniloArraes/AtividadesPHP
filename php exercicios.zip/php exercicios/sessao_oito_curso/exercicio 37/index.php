<?php
    function defineCorCarro( String $corCarro = "Vermeio") {
       
        return $corCarro;
     }


     echo defineCorCarro("azul") . "<br>";
     echo defineCorCarro() . "<br>";
?>