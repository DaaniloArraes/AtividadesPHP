<?php
    $c = [" Teste 1", " Teste 2", " Teste 3", " Teste 4"," Teste 5"];
    $x = implode(",", $c);
    echo $x;
?>