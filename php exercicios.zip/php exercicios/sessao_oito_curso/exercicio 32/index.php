<?php
    function impressaoDados($nome, $idade) {
        echo "Olá $nome, sua idade é $idade";
    }

    impressaoDados("Danilo",28) ;
?>