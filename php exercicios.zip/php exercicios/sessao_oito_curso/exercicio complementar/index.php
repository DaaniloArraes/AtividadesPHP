<?php
/*    function sumEvenNumbers (int $numero) {
        $numeroAcrescido = 0;

        for( $i = 1; $i < $numero; $i++ ) {
            $numeroAcrescido = $numeroAcrescido + $i;

            
        }

        $numeroAcrescido = $numeroAcrescido + $numero;

        return $numeroAcrescido;
    }

    echo sumEvenNumbers(20);

    function countVowels(String $valor): int{
        $w=0;   

        for($i = 0; $i < strlen($valor); $i++ ) 
        {
            if( strtoupper($valor[$i]) == "A" 
            || strtoupper($valor[$i]) == "E"
            || strtoupper($valor[$i]) == "I"
            || strtoupper($valor[$i]) == "O"
            || strtoupper($valor[$i]) == "U"){
                $w++;
            }
        }

        	return $w;
    }
    echo countVowels("Ola, Bom dia");
    function isPrime(int $numero): bool{
        if($numero < 2) return false;

        for ($i = 2; $i < $numero; $i++) {
            if($numero % $i == 0){
                return false;
                break;
            }
        }
        
        return true;
    }

        echo isPrime(50);
    
    function sumDigits(int $numero): int{
        $numeros = $numero . "";
        $teste = 0;
        for($i = 0; $i < strlen($numeros); $i++){
                $teste = $teste + intval($numeros[$i]);
        }

        return (int) $teste;
    } 

    echo sumDigits(1505);
*/


?>